//clear console result
console.clear();

//create a prompt
let name = prompt(
  "Welcome to the Paris 2024 Olympics and Paralympics! What is your name?"
);

//sports list
const list = document.getElementById("olympicSports");
const items = list.getElementsByTagName("li");

//find the index of the last item
let index = 0;

function showNextItem() {
  if (index <= items.length) {
    items[index].style.visibility = "visible";
    index++; //count up
    //delay in miliseconds (one second)
    setTimeout(showNextItem, 1000);
  }
}
showNextItem();
const accordionItems = document.getElementsByClassName("accordion");

//create a loop
for (let i = 0; i < accordionItems.length; i++) {
  accordionItems[i].addEventListener("click", function () {
    // toggle between adding and removing the active class to highlight the button that controls the panel
    this.classList.toggle("active");

    //toggle between hiding and showing the panel
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
//change html style
document.getElementsByClassName("container")[0].style.color = "blue";

//array of athletes
const athlete = [
  "Sky Brown",
  "Georgia Taylor-Brown",
  "Emma Wiggs",
  "Clara Copponi",
  "Alexandra Saint-Pierre",
  "Romane Dicko",
  "Lauritta Onye",
  "Tobi Amusan",
  "Ese Brume"
];

//push the prompt name given into the array to use it as part of the boolean result
athlete.push(name);
console.log(athlete);

//identify html elements
const submitBtn = document.getElementById("submitBtn");
const Q1 = document.getElementById("Q1");
const Q2 = document.getElementById("Q2");
const Q3 = document.getElementById("Q3");
let result = "";

//trigger submit answer function
submitBtn.addEventListener("click", function () {
  //get answer value
  selectElement = document.querySelector("#Q1", "#Q2", "#Q3");
  const A1 = Q1.value;
  const A2 = Q2.value;
  const A3 = Q3.value;

  //check answer value
  console.log(A1);
  console.log(A2);
  console.log(A3);

  //if boolean statement lead to result with interpolation
  if (A1 === "No" && A2 === "No" && A3 === "No") {
    result = `skateboarding 🛹 like ${athlete[0]}.`;
  } else if (A1 === "Yes" && A2 === "No" && A3 === "No") {
    result = `cycling 🚲 like ${athlete[4]}.`;
  } else if (A1 === "Yes" && A2 === "Yes" && A3 === "No") {
    result = `canoeing 🛶 like ${athlete[2]}.`;
  } else if (A1 === "Yes" && A2 === "Yes" && A3 === "Yes") {
    result = `water polo🤽‍♀️ like yourself, ${athlete[9]}!!`;
  } else if (A1 === "Yes" && A2 === "No" && A3 === "Yes") {
    result = `table tennis 🏓 like ${athlete[4]}.`;
  } else if (A1 === "No" && A2 === "No" && A3 === "No") {
    result = `long jump🏃like ${athlete[8]}.`;
  } else if (A1 === "No" && A2 === "Yes" && A3 === "No") {
    result = `triathlon 🏊‍♀️ like ${athlete[1]}.`;
  } else if (A1 === "No" && A2 === "Yes" && A3 === "Yes") {
    result = `aqua aerobics🏊like yourself, ${athlete[9]}!!`;
  } else if (A1 === "No" && A2 === "No" && A3 === "Yes") {
    result = `shot put 🎱 like ${athlete[6]}.`;
  }

  // print result
  document.getElementById("quiz").textContent =
    name +
    ",your Olympic sport is " +
    result +
    " You'd better start training now!🏅";
  console.log(result);
});
//prediction on medals
//trigger submit answer function
submitBtn2.addEventListener("click", function () {
  // Generate a random number between 0 (inclusive) and 1 (exclusive)
  let randomDecimal = Math.random();

  // Scale this number up to 101 to include 100 in the possible outcomes
  let randomNumber = randomDecimal * 101;

  // Round down to the nearest whole number
  let randomInt = Math.floor(randomNumber);

  // Output the result
  document.getElementById("submitBtn2").textContent =
    name + ", your country will win " + randomInt + " medals!";
  console.log(randomInt);
  alert(
    "Disclaimer: this is only a prediction! Fingers crossed for your country!"
  );
});
